const initialState = [{
  id: 0,
  description: 'Use Redux',
  finished: 'true'
},
{
  id: 1,
  description: 'new contract',
  finished: 'false'
},
{
  id: 3,
  description: 'Old  CONTRACT',
  finished: 'true'
},
{
  id: 77,
  description: 'shaka brah',
  finished: 'false'
}]

export default initialState;