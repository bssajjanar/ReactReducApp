import { combineReducers } from 'redux';
import contracts from './contracts';

const rootReducer = combineReducers({
  contracts
});

export default rootReducer;