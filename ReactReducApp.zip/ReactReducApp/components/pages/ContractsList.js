import React, { Component } from 'react/addons';
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import * as ContractActions from '../../actions/ContractActions';

import { fetchOnInit } from '../../decorators'

import { Link } from 'react-router'
import Griddle from 'griddle-react'
import ContractLink from '../ContractLink'
import SearchBar from '../SearchBar'

@connect(state => ({
  contracts: state.contracts.items,
  searchTerm: state.contracts.searchTerm
}))
@fetchOnInit((actions) => {
  //TODO: here list can be updated silently from server when component is mounted
  //actions.fetchContracts()
})
export default class MainSection extends Component {

  columnMeta = [   
     {
      "columnName": "firstName",
      "displayName": "First Name",
      "locked": true,
      "visible": true
    },
     {
      "columnName": "lastName",
      "displayName": "Last Name",
      "locked": true,
      "visible": true
    },
     {
      "columnName": "email",
      "displayName": "Email",
      "locked": true,
      "visible": true
    },
    {
      "columnName": "mobileNum",
      "displayName": "Mobile Num",
      "locked": true,
      "visible": true
    },
    {
      "columnName": "description",
      "displayName": "Address",
      "locked": true,
      "visible": true
    },
    {
      "columnName": "finished",
      "displayName": "Agree",
      "locked": true,
      "visible": true
    }, {
      "columnName": "id",
      "displayName": "Actions",
      "locked": false,
      "visible": true,
      "customComponent": ContractLink
    },
  ];

  constructor(props, context) {
    super(props, context);

    this.actions = bindActionCreators(ContractActions, this.props.dispatch);
  }

  applySearch(query) {
    const queryLowerCase = query.trim().toLowerCase();
    const items = this.props.contracts;
    console.log(items);

    let result = items;

    if (queryLowerCase) {
      result = items.filter(c => {
        return (c.description.toLowerCase().includes(queryLowerCase) ||
          c.id.toString().toLowerCase().includes(queryLowerCase) ||
          c.firstName.toString().toLowerCase().includes(queryLowerCase) ||
          c.lastName.toString().toLowerCase().includes(queryLowerCase) ||
          c.email.toString().toLowerCase().includes(queryLowerCase) ||
          c.mobileNum.toString().toLowerCase().includes(queryLowerCase) ||
          c.finished.toString().toLowerCase().includes(queryLowerCase) )
      });
    }

    return result;
  }

  render() {
    const { searchTerm } = this.props;
    const filteredItems = this.applySearch(searchTerm);
    console.log(searchTerm);

    return (
      <div>
        <Link to="/addContract">
          Create Contacts
        </Link>
        <br/> <br/>
        <SearchBar actions={this.actions} searchTerm={this.props.searchTerm} />
        <br/>
        <section className='main'>
          <Griddle results={filteredItems} columns={["firstName", "lastName", "email", "mobileNum", "description", "finished","id"]} columnMetadata={this.columnMeta} />
        </section>
      </div>
    );
  }
}
