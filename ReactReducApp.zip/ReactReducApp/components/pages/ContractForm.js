import React, { PropTypes, Component } from 'react/addons';
import classnames from 'classnames'
import reactMixin from 'react-mixin';
import ValidationMixin from 'react-validation-mixin';
import Joi from 'joi';
import { Link } from 'react-router';
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import * as ContractActions from '../../actions/ContractActions';

@connect((state, props) => {
  //TODO: move this to decorator or so
  if (props.params && props.params.id){
    let contract = state.contracts.items.filter(c => c.id == props.params.id);
    if (contract.length == 1)
      return { 
        contract : contract[0],
        isEdit: true
      };
  }
  return {};
})
@reactMixin.decorate(ValidationMixin)
//TODO: modify linked state mixin to work with nested properties
@reactMixin.decorate(React.addons.LinkedStateMixin)
export default class ContractForm extends Component {

  initialState = {
    id: null,
    firstName: null,
    lastName: null,
    email: null,
    mobileNum: null,
    description: null,
    finished: null,
    Actions:null
  };

  constructor(props, context) {
    super(props, context);
    
    this.actions = bindActionCreators(ContractActions, this.props.dispatch);

    //TODO: modify validation for nested properties
    this.validatorTypes = {
      id: Joi.number().required().label('Contract Id'),
      description: Joi.when('finished', { is: true, then: Joi.string().min(5).max(25).required() }).label('Description'),
      finished: Joi.boolean().label('Finished')
    }

    this.state = this.props.contract ? this.props.contract : this.initialState;
  }

  renderHelpText(message) {
    return (
      <span className="help-block">{message}</span>
    );
  }

  getClasses(field) {
    return classnames({
      'form-group': true,
      'has-error': !this.isValid(field)
    });
  }

  handleReset(event) {
    event.preventDefault();
    this.clearValidations();
    this.setState(this.initialState);
  }

  handleSubmit(event) {
    event.preventDefault();
    console.log(this.state);
    var onValidate = function(error, validationErrors) {
      if (error) {
        this.setState({
          feedback: 'Form is invalid'
        });
      } else {
        this.setState({
          feedback: 'Form is valid. Ready to send to action creator'
        });

        //TODO: here we need to take only state props related to contract object
        if (this.props.isEdit){
          this.actions.editContract(this.state);
        } else {
          this.actions.addContract(this.state);
        }
      }
    }.bind(this);
    this.validate(onValidate);
  }

  render() {
    const submitBtnLbl = this.props.isEdit ? 'Edit' : 'Create';
    return (
      <section className='row'>
        <Link to="/contracts">
          Contact list
        </Link>
        <h3>Contact Details</h3>
        <form onSubmit={::this.handleSubmit} className='form-horizontal'>
          <fieldset>
            <div className={this.getClasses('id')}>
              <label htmlFor='id'>Id</label>
              <input type='text' id='id' valueLink={this.linkState('id')} onBlur={this.handleValidation('id')} 
                disabled={this.props.isEdit} className='form-control' placeholder='ID' />
              {this.getValidationMessages('id').map(this.renderHelpText)}
            </div>
            <div className={this.getClasses('firstName')}>
              <label htmlFor='firstName'>First Name</label>
              <input type='text' id='firstName' valueLink={this.linkState('firstName')} onBlur={this.handleValidation('firstName')} className='form-control' placeholder='First Name' />
              {this.getValidationMessages('First Name').map(this.renderHelpText)}
            </div>
            <div className={this.getClasses('lastName')}>
              <label htmlFor='lastName'>Last Name</label>
              <input type='text' id='lastName' valueLink={this.linkState('lastName')} onBlur={this.handleValidation('lastName')} className='form-control' placeholder='Last Name' />
              {this.getValidationMessages('Last Name').map(this.renderHelpText)}
            </div>
            <div className={this.getClasses('email')}>
              <label htmlFor='firstName'>Email Address</label>
              <input type='text' id='email' valueLink={this.linkState('email')} onBlur={this.handleValidation('email')} className='form-control' placeholder='Email Address' />
              {this.getValidationMessages('Email Address').map(this.renderHelpText)}
            </div>
             <div className={this.getClasses('mobileNum')}>
              <label htmlFor='mobileNum'>Mobile Number</label>
              <input type='text' id='mobileNum' valueLink={this.linkState('mobileNum')} onBlur={this.handleValidation('mobileNum')} className='form-control' placeholder='Mobile Number' />
              {this.getValidationMessages('Mobile Number').map(this.renderHelpText)}
            </div>
            <div className={this.getClasses('description')}>
              <label htmlFor='description'>Address</label>
              <input type='text' id='description' valueLink={this.linkState('description')} onBlur={this.handleValidation('description')} className='form-control' placeholder='Address' />
              {this.getValidationMessages('description').map(this.renderHelpText)}
            </div>
            <div className={this.getClasses('finished')}>
              <label htmlFor='finished'>Is finished</label>
              <input type='text' id='finished' valueLink={this.linkState('finished')} onBlur={this.handleValidation('finished')}  className='form-control' />
              {this.getValidationMessages('finished').map(this.renderHelpText)}
            </div>
            <div className='form-group'>
              <h3>{this.state.feedback}</h3>
            </div>
            <div className='text-center form-group'>
              <button type='submit' className='btn btn-large btn-primary'>{submitBtnLbl}</button>
              {' '}
              <button onClick={::this.handleReset} className='btn btn-large btn-info'>Reset</button>
            </div>
          </fieldset>
        </form>
      </section>
    );
  }
}
